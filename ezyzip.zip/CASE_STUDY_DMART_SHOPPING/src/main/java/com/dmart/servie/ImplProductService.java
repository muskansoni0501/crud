package com.dmart.servie;

import java.util.ArrayList;
import java.util.List;

import com.dmart.dao.ImplProductServiceDao;
import com.dmart.entity.Product;

public class ImplProductService implements IProduct{
	
	ImplProductServiceDao dao= new ImplProductServiceDao();
	
	@Override
	public String addProduct(Product p) {
		String message=dao.addProduct(p);
		return message;
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> list= dao.getAllProducts();
		return list;
	}

}
