package com.dmart.servie;

import java.util.List;
import com.dmart.entity.Product;

public interface IProduct {
	
	public abstract String addProduct(Product p);
	public abstract List<Product> getAllProducts();

}
